# Thorlabs TSI SDK Python Wrapper

This is the python wrapper for the thorlabs tsi sdk. It uses the ctypes library to wrap around the native thorlabs TSI sdk DLLs. The python wrapper does NOT contain the DLLs, the user will need to set up their environment so their application can find the DLLs. A couple ways this can be done is by adding the DLLs to the working directory of the program or adding the DLLs directory to the PATH envrionment variable (either manually or in python at runtime).
